<?php

Route::resource('persona', 'PersonaController');
Route::get('api/v1/personas','PersonaController@getPersonas');
